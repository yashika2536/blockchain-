# Metamask Browser Setup

This project guides you through installing and using the Metamask crypto wallet browser extension. Learn how to set up a wallet and connect it to decentralized apps (DApps).

## Contents

- [Installation](INSTALLATION.md)
- [Usage Guide](usage/connect_dapp.txt)
- Screenshots of the setup process
