# Installing Metamask Browser Extension

## Step 1: Install Metamask

1. Visit: https://metamask.io
2. Click "Download"
3. Choose your browser (Chrome, Firefox, Edge)
4. Add the extension to your browser

## Step 2: Set Up Your Wallet

1. Click the Metamask icon in the browser toolbar
2. Click "Get Started"
3. Choose "Create a Wallet"
4. Set a strong password
5. Write down your Secret Recovery Phrase

### 🚨 WARNING:
Never share your recovery phrase. Anyone with it can access your wallet.

## Step 3: Done!

You’re ready to connect to DApps!
